/* ============================================================
   InvestidorBR — app.js — Lógica Principal
   ============================================================ */

// ===================== DADOS =====================

const PERFIS = {
  conservador: {
    label: 'Conservador 🛡️',
    cores: ['#3b82f6','#22d3ee','#6366f1','#a5b4fc','#64748b'],
    ativos: [
      { nome:'Tesouro Selic',     tipo:'Renda Fixa',    icon:'🏛️', pct:35 },
      { nome:'CDB Liquidez',      tipo:'Renda Fixa',    icon:'🏦', pct:25 },
      { nome:'LCI/LCA',           tipo:'Renda Fixa',    icon:'🌾', pct:20 },
      { nome:'Tesouro IPCA+',     tipo:'Renda Fixa',    icon:'📊', pct:15 },
      { nome:'Fundo RF DI',       tipo:'Fundo',         icon:'💼', pct:5  },
    ]
  },
  moderado: {
    label: 'Moderado ⚖️',
    cores: ['#c9a227','#f59e0b','#3b82f6','#22c55e','#6366f1'],
    ativos: [
      { nome:'Tesouro IPCA+',     tipo:'Renda Fixa',    icon:'📊', pct:30 },
      { nome:'CDB/LCI',           tipo:'Renda Fixa',    icon:'🏦', pct:20 },
      { nome:'FII (Fundos Imob)', tipo:'Variável',      icon:'🏢', pct:20 },
      { nome:'Ações Brasil',      tipo:'Renda Variável',icon:'📈', pct:20 },
      { nome:'BDR / ETF Global',  tipo:'Exterior',      icon:'🌍', pct:10 },
    ]
  },
  arrojado: {
    label: 'Arrojado 🚀',
    cores: ['#dc2626','#d97706','#16a34a','#7c3aed','#0891b2'],
    ativos: [
      { nome:'Ações Brasil',      tipo:'Renda Variável',icon:'📈', pct:35 },
      { nome:'ETFs Globais',      tipo:'Exterior',      icon:'🌍', pct:20 },
      { nome:'FIIs',              tipo:'Variável',      icon:'🏢', pct:15 },
      { nome:'Cripto (BTC/ETH)',  tipo:'Digital',       icon:'₿',  pct:15 },
      { nome:'Renda Fixa IPCA+',  tipo:'Renda Fixa',    icon:'🛡️', pct:15 },
    ]
  }
};

const FERRAMENTAS = {
  corretoras: [
    { nome:'XP Investimentos', icon:'🏦', cat:'Corretora',
      desc:'A maior corretora independente do Brasil. Ampla variedade de produtos, assessoria especializada e plataforma robusta.',
      tags:['Ações','FIIs','Renda Fixa','Fundos'],
      url:'https://xpi.com.br',
      modal: {
        pros:['Maior plataforma de investimentos','Assessoria personalizada','Mais de 600 fundos disponíveis','App moderno e completo'],
        contras:['Taxa de custódia para pequenos valores','Plataforma pode ser complexa para iniciantes'],
        ideal:'Investidores que buscam variedade e assessoria profissional.',
        minimo:'R$ 0 — sem valor mínimo para abrir conta'
      }
    },
    { nome:'Rico', icon:'💚', cat:'Corretora',
      desc:'Corretora digital simples e acessível. Ideal para quem está começando com zero de taxa de corretagem.',
      tags:['Taxa Zero','Renda Fixa','Ações','ETFs'],
      url:'https://rico.com.vc',
      modal: {
        pros:['Zero taxa de corretagem','Interface simples e intuitiva','Ótimo para iniciantes','Forte em Tesouro Direto'],
        contras:['Menos produtos que grandes corretoras','Suporte pode ser demorado'],
        ideal:'Iniciantes e pequenos investidores.',
        minimo:'R$ 0 — comece com qualquer valor'
      }
    },
    { nome:'Inter Invest', icon:'🧡', cat:'Corretora',
      desc:'Banco e corretora integrados. Invista direto da conta corrente sem transferências, com cashback em investimentos.',
      tags:['Banco+Corretora','Cashback','CDB','Ações'],
      url:'https://inter.co',
      modal: {
        pros:['Tudo integrado: banco + investimentos','Cashback em compras','Sem taxas para Tesouro','App excelente'],
        contras:['Menos fundos que XP','Assessoria limitada'],
        ideal:'Quem já usa o Banco Inter e quer centralizar tudo.',
        minimo:'R$ 1 — aberta para todos'
      }
    },
    { nome:'BTG Pactual', icon:'🔵', cat:'Corretora',
      desc:'Braço digital do maior banco de investimentos da América Latina. Alta qualidade e produtos exclusivos.',
      tags:['Private','CRI/CRA','Debêntures','Global'],
      url:'https://btgpactual.com',
      modal: {
        pros:['Melhor banco de investimentos do Brasil','Acesso a produtos exclusivos','Gestão de patrimônio completa','Internacionalização'],
        contras:['Foco em perfis de maior patrimônio','Interface menos amigável para iniciantes'],
        ideal:'Investidores de maior patrimônio e perfil moderado/arrojado.',
        minimo:'R$ 0 — conta digital gratuita'
      }
    },
    { nome:'Nubank/NuInvest', icon:'💜', cat:'Corretora',
      desc:'A fintech mais famosa do Brasil + corretora. Invista direto pelo app do Nubank de forma simples.',
      tags:['Simples','CDB','Tesouro','ETF'],
      url:'https://nubank.com.br',
      modal: {
        pros:['App excelente e simples','Integração total com Nubank','Zero burocracia','Ótimo para renda fixa'],
        contras:['Menos opções de variável','Sem assessoria especializada'],
        ideal:'Cliente Nubank que quer dar o 1º passo nos investimentos.',
        minimo:'R$ 1 — completamente acessível'
      }
    },
    { nome:'Clear Corretora', icon:'⚡', cat:'Corretora',
      desc:'Especializada em day trade e operações ativas. Taxa zero de corretagem e plataforma profissional.',
      tags:['Day Trade','Zero taxa','Mini Contratos','Swing Trade'],
      url:'https://clear.com.br',
      modal: {
        pros:['Zero corretagem','Plataforma profissional','Ótima para ativos','Mini-contratos acessíveis'],
        contras:['Foco em traders ativos','Menos produtos de renda fixa'],
        ideal:'Traders e investidores ativos no mercado de ações.',
        minimo:'R$ 0'
      }
    },
  ],
  'robos-c': [
    { nome:'Warren', icon:'🤖', cat:'Robô Consultor',
      desc:'Primeiro robô-consultor do Brasil. Cria carteiras personalizadas automaticamente baseado no seu perfil.',
      tags:['Automático','Perfil','Rebalanceamento','Fundos'],
      url:'https://oiwarren.com',
      modal: {
        pros:['Gestão automática de carteiras','Rebalanceamento automático','Interface linda e simples','Ótimo para quem não tem tempo'],
        contras:['Taxa de gestão anual','Menos flexível que montar carteira própria'],
        ideal:'Investidores que querem delegar a gestão sem pagar assessor humano.',
        minimo:'R$ 50 — muito acessível'
      }
    },
    { nome:'Magnetis', icon:'🧲', cat:'Robô Consultor',
      desc:'Gestora digital que monta e cuida da sua carteira de forma 100% automática com baixo custo.',
      tags:['Gestão Automática','ETF','Baixo Custo','Metas'],
      url:'https://magnetis.com.br',
      modal: {
        pros:['Carteira totalmente automática','Foco em ETFs (baixo custo)','Excelentes relatórios','Orientado a metas'],
        contras:['Menos controle individual','Portfólio mais padronizado'],
        ideal:'Investidor de longo prazo que busca crescimento passivo com baixo custo.',
        minimo:'R$ 1.000 — investimento mínimo inicial'
      }
    },
    { nome:'Vérios', icon:'🧬', cat:'Robô Consultor',
      desc:'Plataforma de gestão automática com foco em evidências científicas e alocação eficiente.',
      tags:['Evidências','Científico','Diversificação','ETF'],
      url:'https://verios.com.br',
      modal: {
        pros:['Baseado em pesquisas acadêmicas','Excelente diversificação','Transparência total','Relatórios detalhados'],
        contras:['Menos conhecido','Interface simples'],
        ideal:'Investidores que valorizam a base científica e eficiência de mercado.',
        minimo:'R$ 1.000'
      }
    },
    { nome:'Carteiras Auto XP', icon:'📦', cat:'Robô Consultor',
      desc:'Carteiras gerenciadas automaticamente pela XP com estratégias pré-definidas por especialistas.',
      tags:['XP','Automático','Estratégias','Especialistas'],
      url:'https://xpi.com.br',
      modal: {
        pros:['Poder da XP com automação','Diversas estratégias disponíveis','Rebalanceamento automático','Suporte especializado'],
        contras:['Taxas maiores','Dependente da XP'],
        ideal:'Clientes XP que querem automatizar sem sair da plataforma.',
        minimo:'R$ 5.000 — investimento mínimo'
      }
    },
  ],
  'robos-t': [
    { nome:'SmarttBot', icon:'⚡', cat:'Robô Trader',
      desc:'Plataforma líder de robôs para a B3. Conecta seu robô diretamente às corretoras para operar automaticamente.',
      tags:['B3','Automação','Mini-Índice','Mini-Dólar'],
      url:'https://smarttbot.com',
      modal: {
        pros:['Maior marketplace de robôs do Brasil','Integração direta com corretoras','Histórico e backtesting','Vários robôs disponíveis'],
        contras:['Requer conhecimento de mercado','Assinatura mensal','Risco inerente de day trade'],
        ideal:'Traders que querem automatizar operações na B3 com mini-contratos.',
        minimo:'R$ 500/mês (assinatura) + capital de operação'
      }
    },
    { nome:'Tryd', icon:'🎯', cat:'Robô Trader',
      desc:'Plataforma profissional de automação de estratégias para o mercado de renda variável.',
      tags:['Estratégias','Professional','Backtesting','Renda Variável'],
      url:'https://tryd.com.br',
      modal: {
        pros:['Plataforma profissional','Excelente backtesting','Alta customização','Suporte técnico especializado'],
        contras:['Mais técnico','Curva de aprendizado alta'],
        ideal:'Traders profissionais e quantitativos.',
        minimo:'Planos a partir de R$ 200/mês'
      }
    },
    { nome:'Trade System', icon:'🤖', cat:'Robô Trader',
      desc:'Crie, teste e rode suas estratégias automaticamente em ações, futuros e opções na B3.',
      tags:['Ações','Futuros','Opções','Criar Estratégias'],
      url:'https://tradesystem.com.br',
      modal: {
        pros:['Crie sua própria estratégia','Suporta múltiplos ativos','Comunidade ativa','Backtesting robusto'],
        contras:['Requer programação para estratégias avançadas','Interface densa'],
        ideal:'Desenvolvedores de estratégias e traders quantitativos.',
        minimo:'R$ 150/mês'
      }
    },
    { nome:'Profit Pro', icon:'💹', cat:'Robô Trader',
      desc:'Plataforma completa da Nelogica com automação integrada. A mais usada por traders profissionais.',
      tags:['Nelogica','Professional','DDE','Api'],
      url:'https://nelogica.com.br',
      modal: {
        pros:['Referência no mercado','Altamente estável','Suporte a API e DDE','Amplitude de ativos'],
        contras:['Custo elevado','Interface menos moderna'],
        ideal:'Traders profissionais e mesas de operação.',
        minimo:'A partir de R$ 350/mês'
      }
    },
  ],
  consolidadores: [
    { nome:'Gorila', icon:'🦍', cat:'Consolidador',
      desc:'Consolide todos os seus investimentos em um único painel. Conecta com mais de 100 corretoras.',
      tags:['Multi-corretora','Dashboard','IR','Rentabilidade'],
      url:'https://gorila.com.br',
      modal: {
        pros:['Mais de 100 corretoras conectadas','Cálculo automático de IR','Dashboard completo','Gratuito para básico'],
        contras:['Plano pago para recursos avançados','Integrações podem atrasar'],
        ideal:'Quem tem investimentos em várias corretoras.',
        minimo:'Gratuito (básico) / R$ 29,90/mês (premium)'
      }
    },
    { nome:'Kinvo', icon:'🐙', cat:'Consolidador',
      desc:'App de controle financeiro pessoal + consolidador de investimentos com interface visual incrível.',
      tags:['App','Visual','Multi-ativo','Metas'],
      url:'https://kinvo.com.br',
      modal: {
        pros:['Interface visual belíssima','Multi-ativo e multi-corretora','Acompanhamento de metas','Heatmap de carteira'],
        contras:['Algumas integrações manuais','Plano pago para tudo'],
        ideal:'Quem quer visualizar a carteira de forma bonita e organizada.',
        minimo:'R$ 19,90/mês (plano pago)'
      }
    },
    { nome:'Meu Portfólio', icon:'📋', cat:'Consolidador',
      desc:'Ferramenta gratuita para montagem e acompanhamento de portfólio com dados da B3.',
      tags:['Gratuito','B3','Ações','FIIs'],
      url:'https://meuportfolio.digital',
      modal: {
        pros:['100% gratuito','Dados em tempo real da B3','Simples e direto','Ações e FIIs'],
        contras:['Funcionalidades básicas','Menos integrações'],
        ideal:'Investidores de Ações e FIIs que querem controle gratuito.',
        minimo:'Grátis'
      }
    },
    { nome:'Status Invest', icon:'📊', cat:'Consolidador',
      desc:'A maior plataforma de análise de FIIs, Ações e Renda Fixa do Brasil. Dados fundamentalistas gratuitos.',
      tags:['Análise','FIIs','Ações','Gratuito'],
      url:'https://statusinvest.com.br',
      modal: {
        pros:['Melhor análise de FIIs','Top em Ações e Dividendos','Gratuito e completo','Comunidade enorme'],
        contras:['Foco em análise, não em carteira','Sem integração com corretoras'],
        ideal:'Investidores que fazem análise fundamentalista.',
        minimo:'Grátis'
      }
    },
  ]
};

const MERCADO_DATA = [
  { nome:'Ibovespa',     val:'134.280',  var:'+1,2%', pos:true },
  { nome:'Dólar (R$)',   val:'5,08',     var:'-0,3%', pos:false },
  { nome:'CDI',          val:'12,50%',   var:'a.a.',  pos:true },
  { nome:'IPCA',         val:'4,83%',    var:'acum.', pos:null },
  { nome:'Selic',        val:'13,75%',   var:'a.a.',  pos:true },
  { nome:'Ouro (g)',     val:'R$310',    var:'+0,8%', pos:true },
  { nome:'BTC/BRL',      val:'R$325K',   var:'+2,1%', pos:true },
  { nome:'S&P 500',      val:'5.211',    var:'+0,5%', pos:true },
];

// ===================== INIT =====================

document.addEventListener('DOMContentLoaded', () => {
  renderMercado();
  renderCarteira('conservador');
  renderTools('corretoras');
  setupNavScroll();
});

// ===================== NAVEGAÇÃO =====================

function scrollToSection(id) {
  document.getElementById(id).scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function setupNavScroll() {
  const sections = ['inicio','simulador','carteira','ferramentas','mercado'];
  const links = {};
  sections.forEach(s => { links[s] = document.getElementById('nav-'+s); });

  window.addEventListener('scroll', () => {
    let current = 'inicio';
    sections.forEach(s => {
      const el = document.getElementById(s);
      if (el && window.scrollY >= el.offsetTop - 100) current = s;
    });
    Object.values(links).forEach(l => l?.classList.remove('active'));
    if (links[current]) links[current].classList.add('active');
  });
}

// ===================== SIMULADOR =====================

function updatePrazoLabel(val) {
  document.getElementById('prazo-label').textContent = val + ' ano' + (val > 1 ? 's' : '');
  const input = document.getElementById('sim-prazo');
  const pct = ((val - 1) / 39) * 100;
  input.style.background = `linear-gradient(to right, var(--gold) ${pct}%, #e0d8c8 ${pct}%)`;
}

function setTaxa(val) {
  document.getElementById('sim-taxa').value = val;
  document.querySelectorAll('.preset-btn').forEach(b => b.classList.remove('active-preset'));
  const map = { 12.5:'preset-cdi', 18:'preset-ipca', 15:'preset-ibov', 24:'preset-max' };
  if (map[val]) document.getElementById(map[val])?.classList.add('active-preset');
}

function calcSim() {
  const inicial = parseFloat(document.getElementById('sim-inicial').value) || 0;
  const mensal  = parseFloat(document.getElementById('sim-mensal').value)  || 0;
  const taxaA   = parseFloat(document.getElementById('sim-taxa').value)    || 0;
  const anos    = parseInt(document.getElementById('sim-prazo').value)      || 10;
  const meses   = anos * 12;
  const taxaM   = Math.pow(1 + taxaA / 100, 1 / 12) - 1;

  const dadosPatrimonio = [];
  const dadosAporte     = [];
  let patrimonio = inicial;
  let totalAportado = inicial;

  for (let m = 0; m <= meses; m++) {
    if (m > 0) {
      patrimonio = patrimonio * (1 + taxaM) + mensal;
      totalAportado += mensal;
    }
    if (m % 12 === 0 || m === meses) {
      dadosPatrimonio.push({ x: m / 12, y: patrimonio });
      dadosAporte.push({ x: m / 12, y: totalAportado });
    }
  }

  const rendimento = patrimonio - totalAportado;

  // Exibe resultado
  document.getElementById('sim-result').style.display = 'block';
  document.getElementById('sim-result').scrollIntoView({ behavior:'smooth', block:'nearest' });

  // Badges
  const fator = (patrimonio / (inicial || 1)).toFixed(1);
  document.getElementById('result-badges').innerHTML = `
    <span class="result-badge badge-gold">💰 ${fator}x multiplicado</span>
    <span class="result-badge badge-green">📈 ${taxaA}% a.a.</span>
  `;

  // Canvas
  drawChart(dadosPatrimonio, dadosAporte, anos);

  // Números
  document.getElementById('result-nums').innerHTML = `
    <div class="result-num-item">
      <div class="result-num-val">${fmt(patrimonio)}</div>
      <div class="result-num-lbl">Patrimônio Final</div>
    </div>
    <div class="result-num-item">
      <div class="result-num-val">${fmt(totalAportado)}</div>
      <div class="result-num-lbl">Total Investido</div>
    </div>
    <div class="result-num-item">
      <div class="result-num-val" style="color:#16a34a">${fmt(rendimento)}</div>
      <div class="result-num-lbl">Rendimentos 🎉</div>
    </div>
  `;

  // Recomendação automação
  renderAutomacao(taxaA);
}

function drawChart(dados, dadosAporte, anos) {
  const canvas = document.getElementById('sim-chart');
  const ctx = canvas.getContext('2d');
  const W = canvas.offsetWidth || 500;
  const H = 220;
  canvas.width = W * window.devicePixelRatio;
  canvas.height = H * window.devicePixelRatio;
  ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
  canvas.style.width = W + 'px'; canvas.style.height = H + 'px';

  const pad = { top:20, right:20, bottom:36, left:70 };
  const innerW = W - pad.left - pad.right;
  const innerH = H - pad.top - pad.bottom;

  const maxY = dados[dados.length-1].y;

  function toX(xi) { return pad.left + (xi / anos) * innerW; }
  function toY(y)  { return pad.top + innerH - (y / maxY) * innerH; }

  // Background
  ctx.clearRect(0, 0, W, H);

  // Grid lines
  ctx.strokeStyle = 'rgba(0,0,0,0.05)';
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = pad.top + (innerH / 4) * i;
    ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(W - pad.right, y); ctx.stroke();
    const val = maxY * (1 - i / 4);
    ctx.fillStyle = '#7a6e60'; ctx.font = '11px Inter'; ctx.textAlign = 'right';
    ctx.fillText(fmtShort(val), pad.left - 8, y + 4);
  }

  // Área aportado (azul suave)
  ctx.beginPath();
  ctx.moveTo(toX(dadosAporte[0].x), toY(dadosAporte[0].y));
  dadosAporte.forEach(d => ctx.lineTo(toX(d.x), toY(d.y)));
  ctx.lineTo(toX(dadosAporte[dadosAporte.length-1].x), pad.top + innerH);
  ctx.lineTo(toX(dadosAporte[0].x), pad.top + innerH);
  ctx.closePath();
  ctx.fillStyle = 'rgba(59,130,246,0.15)'; ctx.fill();

  // Linha aportado
  ctx.beginPath();
  ctx.moveTo(toX(dadosAporte[0].x), toY(dadosAporte[0].y));
  dadosAporte.forEach(d => ctx.lineTo(toX(d.x), toY(d.y)));
  ctx.strokeStyle = '#3b82f6'; ctx.lineWidth = 2; ctx.stroke();

  // Área patrimônio (dourada)
  const gradGold = ctx.createLinearGradient(0, pad.top, 0, pad.top + innerH);
  gradGold.addColorStop(0, 'rgba(201,162,39,0.35)');
  gradGold.addColorStop(1, 'rgba(201,162,39,0.02)');
  ctx.beginPath();
  ctx.moveTo(toX(dados[0].x), toY(dados[0].y));
  dados.forEach(d => ctx.lineTo(toX(d.x), toY(d.y)));
  ctx.lineTo(toX(dados[dados.length-1].x), pad.top + innerH);
  ctx.lineTo(toX(dados[0].x), pad.top + innerH);
  ctx.closePath();
  ctx.fillStyle = gradGold; ctx.fill();

  // Linha patrimônio
  ctx.beginPath();
  ctx.moveTo(toX(dados[0].x), toY(dados[0].y));
  dados.forEach(d => ctx.lineTo(toX(d.x), toY(d.y)));
  const gradLine = ctx.createLinearGradient(0, 0, W, 0);
  gradLine.addColorStop(0, '#c9a227'); gradLine.addColorStop(1, '#a07c10');
  ctx.strokeStyle = gradLine; ctx.lineWidth = 3; ctx.stroke();

  // Labels eixo X
  ctx.fillStyle = '#7a6e60'; ctx.font = '11px Inter'; ctx.textAlign = 'center';
  for (let i = 0; i <= anos; i += Math.ceil(anos / 5)) {
    ctx.fillText(i + 'a', toX(i), H - 8);
  }

  // Legenda
  const lx = pad.left + 8;
  const ly = pad.top + 10;
  ctx.fillStyle = '#c9a227'; ctx.fillRect(lx, ly, 24, 4);
  ctx.fillStyle = '#1a1612'; ctx.font = '11px Inter'; ctx.textAlign = 'left';
  ctx.fillText('Patrimônio', lx + 30, ly + 5);
  ctx.fillStyle = '#3b82f6'; ctx.fillRect(lx, ly + 14, 24, 4);
  ctx.fillStyle = '#4a4035';
  ctx.fillText('Total Investido', lx + 30, ly + 19);
}

function renderAutomacao(taxa) {
  const box = document.getElementById('automacao-recomendacao');

  if (taxa <= 15) {
    box.innerHTML = `
      <div class="auto-box auto-box-warren">
        <div class="auto-box-title">🤖 Sua estratégia combina com automação passiva</div>
        <div class="auto-box-desc">
          Com uma rentabilidade conservadora/moderada de <strong>${taxa}% a.a.</strong>, o ideal é usar um 
          <strong>robô consultor</strong> que monta e rebalanceia a carteira automaticamente por você.
          A <strong>Warren</strong> faz exatamente isso — sem você precisar se preocupar com gestão diária.
        </div>
        <a class="auto-box-btn" href="https://oiwarren.com" target="_blank">
          🤖 Conhecer a Warren →
        </a>
        &nbsp;
        <a class="auto-box-btn" href="https://magnetis.com.br" target="_blank" style="background:#0ea5e9">
          🧲 Ver Magnetis →
        </a>
      </div>`;
  } else {
    box.innerHTML = `
      <div class="auto-box auto-box-smartt">
        <div class="auto-box-title">⚡ Estratégia agressiva — use um Robô Trader</div>
        <div class="auto-box-desc">
          Para buscar <strong>${taxa}% a.a. ou mais</strong>, você precisa de operações ativas no mercado.
          Um <strong>robô trader</strong> como o SmarttBot pode operar automaticamente em mini-contratos 
          da B3 24h por dia, aproveitando oscilações do mercado sem você precisar estar na frente do computador.
        </div>
        <a class="auto-box-btn" href="https://smarttbot.com" target="_blank">
          ⚡ Conhecer SmarttBot →
        </a>
        &nbsp;
        <a class="auto-box-btn" href="https://clear.com.br" target="_blank" style="background:#7c3aed">
          📈 Abrir na Clear →
        </a>
      </div>`;
  }
}

// ===================== CARTEIRA =====================

let perfilAtual = 'conservador';

function selectPerfil(perfil) {
  perfilAtual = perfil;
  document.querySelectorAll('.perfil-card').forEach(c => c.classList.remove('active'));
  document.getElementById('perfil-'+perfil).classList.add('active');
  renderCarteira(perfil);
}

function renderCarteira(perfil) {
  const dados = PERFIS[perfil];
  const canvas = document.getElementById('carteira-chart');
  const ctx = canvas.getContext('2d');
  const size = 280;
  ctx.clearRect(0, 0, size, size);

  const cx = size / 2, cy = size / 2, r = 110, inner = 65;
  let startAngle = -Math.PI / 2;

  dados.ativos.forEach((a, i) => {
    const slice = (a.pct / 100) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, r, startAngle, startAngle + slice);
    ctx.closePath();
    ctx.fillStyle = dados.cores[i];
    ctx.fill();
    ctx.strokeStyle = '#fff'; ctx.lineWidth = 3; ctx.stroke();
    startAngle += slice;
  });

  // Donut hole
  ctx.beginPath(); ctx.arc(cx, cy, inner, 0, Math.PI*2);
  ctx.fillStyle = '#ffffff'; ctx.fill();

  // Centro
  ctx.fillStyle = '#1a1612'; ctx.font = 'bold 20px Inter'; ctx.textAlign = 'center';
  ctx.fillText(dados.label.split(' ')[0], cx, cy);
  ctx.font = '13px Inter'; ctx.fillStyle = '#7a6e60';
  ctx.fillText('perfil', cx, cy + 18);

  // Legenda
  const legend = document.getElementById('carteira-legend');
  legend.innerHTML = dados.ativos.map((a, i) => `
    <div class="legend-item">
      <div class="legend-dot" style="background:${dados.cores[i]}"></div>
      <span style="font-weight:600">${a.pct}%</span> ${a.nome}
    </div>
  `).join('');

  // Lista ativos
  const ativos = document.getElementById('carteira-ativos');
  ativos.innerHTML = dados.ativos.map(a => `
    <div class="ativo-row">
      <div class="ativo-icon">${a.icon}</div>
      <div class="ativo-info">
        <div class="ativo-nome">${a.nome}</div>
        <div class="ativo-tipo">${a.tipo}</div>
        <div class="ativo-bar"><div class="ativo-bar-fill" style="width:${a.pct}%"></div></div>
      </div>
      <div class="ativo-pct">${a.pct}%</div>
    </div>
  `).join('');
}

// ===================== FERRAMENTAS =====================

function showToolTab(cat) {
  document.querySelectorAll('.tool-tab').forEach(t => t.classList.remove('active'));
  document.getElementById('tab-'+cat).classList.add('active');
  renderTools(cat);
}

function renderTools(cat) {
  const list = FERRAMENTAS[cat] || [];
  document.getElementById('tools-content').innerHTML = list.map(t => `
    <div class="tool-card" onclick="openModal('${cat}','${t.nome}')">
      <div class="tool-card-header">
        <div class="tool-card-icon">${t.icon}</div>
        <div>
          <div class="tool-card-name">${t.nome}</div>
          <div class="tool-card-cat">${t.cat}</div>
        </div>
      </div>
      <div class="tool-card-desc">${t.desc}</div>
      <div class="tool-card-tags">${t.tags.map(g => `<span class="tool-tag">${g}</span>`).join('')}</div>
      <div class="tool-card-btn">Ver detalhes →</div>
    </div>
  `).join('');
}

// ===================== MERCADO =====================

function renderMercado() {
  document.getElementById('mercado-grid').innerHTML = MERCADO_DATA.map(m => `
    <div class="mercado-card">
      <div class="mercado-nome">${m.nome}</div>
      <div class="mercado-val">${m.val}</div>
      <div class="mercado-var ${m.pos === true ? 'var-pos' : m.pos === false ? 'var-neg' : ''}">${m.var}</div>
    </div>
  `).join('');
}

// ===================== MODAL =====================

function openModal(cat, nome) {
  const list  = FERRAMENTAS[cat] || [];
  const tool  = list.find(t => t.nome === nome);
  if (!tool) return;
  const m = tool.modal;

  document.getElementById('modal-content').innerHTML = `
    <div class="modal-header">
      <div class="modal-icon">${tool.icon}</div>
      <div class="modal-title">${tool.nome}</div>
      <div class="modal-cat">${tool.cat}</div>
    </div>
    <div class="modal-body">
      <p>${tool.desc}</p>
      <br>
      <strong>✅ Pontos positivos</strong>
      <ul>${m.pros.map(p => `<li>${p}</li>`).join('')}</ul>
      <strong>⚠️ Pontos de atenção</strong>
      <ul>${m.contras.map(c => `<li>${c}</li>`).join('')}</ul>
      <br>
      <p><strong>👤 Ideal para:</strong> ${m.ideal}</p>
      <p><strong>💵 Mínimo:</strong> ${m.minimo}</p>
    </div>
    <div class="modal-footer">
      <a class="btn-gold" href="${tool.url}" target="_blank" style="text-decoration:none">Acessar ${tool.nome} 🚀</a>
      <button class="btn-outline" onclick="closeModal()">Fechar</button>
    </div>
  `;

  document.getElementById('modal-overlay').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  document.getElementById('modal-overlay').classList.remove('open');
  document.body.style.overflow = '';
}

// ===================== UTILS =====================

function fmt(val) {
  return 'R$ ' + val.toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

function fmtShort(val) {
  if (val >= 1_000_000) return 'R$' + (val / 1_000_000).toFixed(1) + 'M';
  if (val >= 1_000)     return 'R$' + (val / 1_000).toFixed(0) + 'K';
  return 'R$' + val.toFixed(0);
}
